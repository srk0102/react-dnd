**Update-1**
Date: 03/30/24
Desc:
* Updated navbar
* Removed Links component

**Fix-4**
Date: 02/27/24
Desc:
* Fixed Navbar's z-index 
* Fixed sidebar's z-index

**Fix-3**
Date: 02/26/24
Desc:
* Fixed errors in footer and Navbar dynamic comps
* Fixed some default css problems in index.css and app.css

**Feat-4**
Date: 02/24/24
Desc:
* Created 1 shopping card type1 need to make 2 more
* fixed apis for side bar

**Feat-3**
Date: 02/24/24
Desc:
* Created 2 sidebar positions for Type1 in dynamic comp
* Added 1 parent sidebar comp

**Fix-2**
Date: 02/24/24
Desc:
* Fixed navbar naming issue
* Fixed strapi url

**Feat-2**
Date: 02/22/24
Desc:
* Created 3 Footers in dynamic comps
* Added 1 parent footer comp

**Fix-1**
Date: 02/22/24
Desc:
* fixed some default names in dynamic component

**Feat-1**
Date: 02/21/24
Desc:
* Added Strapi integration to the app
* Created 2 NavBar comps and created dynamic Component folder
* Added 1 new Env Variables (VITE_APP_STRAPI_KEY)

**INITIAL**
Date: 02/16/24
Desc:
* Added boilerplate wit react, vite, strapi and tailwind